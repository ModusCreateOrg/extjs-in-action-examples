<?php
    sleep(10);
?>

{ success : true }