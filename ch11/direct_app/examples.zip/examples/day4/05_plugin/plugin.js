
Ext.define('MyApp.MyPlugin', {
    extend : 'Ext.AbstractPlugin',
    alias  : 'plugin.MyApp.MyPlugin',

    init : function() {
        Ext.apply(this.cmp, this.cmpOverrides);
    },

    cmpOverrides : {
        slideOut : function() {
            this.el.animate({
                duration : 1000,
                to : {
                    y : (this.getHeight() * -1) - 5,
                    x : this.el.getLeft()
                },
                scope    : this,
                callback : this.onAfterSlideOut
            });
        },
        onAfterSlideOut : function() {
            this.destroy();
        }
    }
});




