Ext.onReady(function() {

    Ext.create('Ext.window.Window', {
        renderTo : Ext.getBody(),
        height   : 150,
        width    : 200,
        plugins  : {
            ptype : 'MyApp.MyPlugin'
        },
        layout : {
            type : 'hbox',
            align : 'stretch'
        },
        defaults: {
            frame : true,
            flex  : 1
        },
        items : [
            {
                html  : 'Panel 1',
                title : 'Panel 1 title'
            },
            {
                html  : 'Panel 2',
                title : 'Panel 1 title'
            }
        ],
        buttons  : [
            {
                text    : 'Close me',
                handler : function() {
                    this.up('window').slideOut();
                }
            }
        ]
    }).show();
});
