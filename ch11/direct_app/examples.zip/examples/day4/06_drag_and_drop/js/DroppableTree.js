Ext.define('DroppableTree', {
    extend : 'Ext.tree.Panel',
    alias  : 'widget.droppabletree',

    rootVisible : false,

    initComponent : function() {
        this.store   = this.buildStore();
        this.columns = this.buildColumns();
        this.callParent();
    },
    buildStore : function() {

        var treeData = {
            children : [
                {
                    project  : 'Financial magazine',
                    leader   : 'Pat Sheridan',
                    teamName : 'Project teams',
                    children : [
                        {
                            teamName : 'UI/UX',
                            leader   : 'Jay Garcia',
                            children : [
                                {
                                    task        : 'UI Architecture',
                                    teamMember  : 'Jay Garcia',
                                    leaf        : true,
                                    hours       : 40
                                },
                                {
                                    task       : 'UX/UI Design',
                                    teamMember : 'Pat Sheridan',
                                    leaf       : true,
                                    hours      : 40
                                }
                            ]
                        },
                        {
                            teamName : 'Server side PHP',
                            leader   : 'Anthony De Moss',
                            children : [
                                {
                                    teamMember : 'Jordan Laramy',
                                    leaf       : true,
                                    hours      : 40
                                }
                            ]
                        },
                        {
                            teamName : 'Database Architecture',
                            leader   : 'Nury Sword',
                            children : [
                                {
                                    task       : 'Schema development',
                                    teamMember : 'TBD',
                                    leaf       : true,
                                    hours      : 40
                                }
                            ]
                        },
                        {
                            teamName : 'UI Development',
                            leader   : 'Jay Garcia',
                            children : [
                                {
                                    teamMember : 'Cemal Can Efe',
                                    leaf       : true,
                                    hours      : 80
                                },
                                {
                                    teamMember : 'Asim Safa',
                                    leaf       : true,
                                    hours      : 80
                                }
                            ]
                        }
                    ]
                }
            ]
        };


        // should be pushed outside of this class
        Ext.define('MyApp.TreeModel', {
            extend : 'Ext.data.Model',
            fields : [
                'project',
                'teamMember',
                'teamName',
                'leader',
                'hours',
                'total'
            ]
        });

        return Ext.create('Ext.data.TreeStore', {
            model      : 'MyApp.TreeModel',
            folderSort : true,
            proxy      : {
                type : 'memory',
                data : treeData
            }
        });

    },
    buildColumns : function() {
        return [
            {
                xtype           : 'treecolumn', // undocumented
                text            : 'Teams',
                dataIndex       : 'teamName',
                flex            : 1,
                defaultRenderer : function(val, meta, record) {
                    var data = record.data;
                    return data.teamName || data.teamMember;
                }
            }
        ];
    }
});