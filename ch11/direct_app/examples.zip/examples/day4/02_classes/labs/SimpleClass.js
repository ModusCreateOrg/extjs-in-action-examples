/*
   Goals:
    Create a simple class using Ext.define
    Play around with config : {} and auto generated setters and getters
    Instantiate your class

*/

Ext.define('YOUR_CLASS_NAME_HERE', {
    /* CONFIG HERE */
});