/*
   Goals:

*/

Ext.define('YOUR_EXTENSION_CLASS_NAME_HERE', {
    extend : 'YOUR_SIMPLE_CLASS_NAME_HERE'
    /* CONFIG HERE */
});