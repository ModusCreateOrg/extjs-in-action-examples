

Ext.define('MyApp.MyClass', {
    config : {
        age       : 32,
        firstName : 'Jay',
        lastName  : 'Garcia'
    },
    constructor : function(cfg) {
        this.initConfig(cfg);
        console.info(this.$className, 'was instantiated');
    }
});