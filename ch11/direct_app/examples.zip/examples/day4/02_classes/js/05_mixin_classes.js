Ext.define('Cars.Shifter', {
    constructor : function() {
        this.gear = 'P';
    },
    shiftTo : function(gear) {
        this.gear = gear;
    },
    setPark : function() {
        this.shiftTo('P')
    },
    drive : function() {
        this.shiftTo('D');
        console.log('.oO( )( ) vrrrrrroom!');
    },
    stop : function() {
        this.setPark();
        console.warn('I am now parked!');
    }
});


Ext.define('Cars.Basic', {
    engine       : 'i4',
    wheelSize    : 15,
    stereo       : 'basic',
    interior     : 'cloth',
    transmission : 'manual',
    color        : undefined,
    numDoors     : 2,
    mixins : {
        shifter : 'Cars.Shifter'
    },
    constructor : function(cfg) {
        Ext.apply(this, cfg ||{});
        this.mixins.shifter.constructor.call(this)
    }
//    drive : function() {
//        console.info('WOOT')
//        this.mixins.shifter.drive.call(this);
//    }
});

var myBasicCar = Ext.create('Cars.Basic', {
    color : 'yellow'
});

myBasicCar.drive();
console.info(myBasicCar.gear);



