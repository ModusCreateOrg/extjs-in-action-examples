Ext.define('Cars.Basic', {
    engine       : 'i4',
    wheelSize    : 15,
    stereo       : 'basic',
    interior     : 'cloth',
    transmission : 'manual',
    color        : undefined,
    numDoors     : 2,
    constructor  : function(cfg) {
        Ext.apply(this, cfg || {});
    },
    drive : function(speed) {
        console.info('I am driving my', this.color, this.engine, 'really ', speed)
    }
});

Ext.define('Cars.Value', {
    extend : 'Cars.Basic',

    engine       : 'v6',
    wheelSize    : 16,
    stereo       : 'cd',
    interior     : 'micro-fiber',
    transmission : 'automatic',
    drive        : function() {
        this.callParent(arguments);
        console.warn('Damn cops!');
    }
});

Ext.define('Cars.Sports', {
    extend : 'Cars.Value',

    engine       : 'twin-turbo v6',
    wheelSize    : 17,
    stereo       : 'surround',
    interior     : 'leather',
    transmission : '6spd-manual',
    drive        : function() {
        this.callParent(arguments);
        console.info('Haha!! i am too fast for them!')
    }
});