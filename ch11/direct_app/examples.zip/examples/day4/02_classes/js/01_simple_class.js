Ext.define('MyApp.Person', {
    firstName : 'Jay',
    lastName  : 'Garcia',
    // primitives

    // Objects/Arrays

    constructor : function() {
        console.info(this.$className, 'was instantiated');
    },
    sayHello : function() {
        console.log(this.firstName, 'says hi!');
    }
});


Ext.create('MyApp.Person');