Ext.require(['Ext.window.Window']);

Ext.onReady(function() {
//    console.warn('started');
    Ext.create('Ext.window.Window', {
        width       : 100,
        collapsible : true,
        html        : 'Hello There'
    }).show();
//    console.warn('ended');

});