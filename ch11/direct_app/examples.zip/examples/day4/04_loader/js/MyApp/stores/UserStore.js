Ext.define('MyApp.stores.UserStore', {
    extend    : 'Ext.data.Store',
    singleton : true,
    requires  : ['MyApp.models.UserModel'],

    model     : 'MyApp.models.UserModel',
    storeId   : 'MyApp.stores.UserStore',

    autoLoad : true,
    proxy : {
        type : 'memory',
        data : [
            {
                firstName : 'Louis',
                lastName  : 'Dobbs',
                dob       : '12/21/98',
                userName  : 'ldobbs'
            },
            {
                firstName : 'Sam',
                lastName  : 'Conran',
                dob       : '03/23/54',
                userName  : 'sconran'
            },
            {
                firstName : 'John',
                lastName  : 'Smith',
                dob       : '01/18/82',
                userName  : 'jsmith'
            }
        ]
    }
});