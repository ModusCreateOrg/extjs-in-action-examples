Ext.define('MyApp.registration.UsersGridPanel', {
    extend : 'Ext.grid.Panel',
    alias : 'widget.MyApp.registration.UsersGridPanel',
    requires : [
        'MyApp.stores.UserStore'
    ],

    initComponent : function() {
        this.store   = MyApp.stores.UserStore;
        this.columns = this.buildColumns();
        this.callParent();
    },
    buildColumns : function() {
        return {
            defaults : { flex : 1 },
            items    : [
                {
                    header    : 'First Name',
                    dataIndex : 'firstName'
                },
                {
                    header    : 'Last Name',
                    dataIndex : 'lastName'
                },
                {
                    header    : 'DOB',
                    dataIndex : 'dob'
                },
                {
                    header    : 'Login',
                    dataIndex : 'userName'
                }
            ]
        }
    }
});