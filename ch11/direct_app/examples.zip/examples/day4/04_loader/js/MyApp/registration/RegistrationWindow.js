
Ext.define('MyApp.registration.RegistrationWindow', {
    extend   : 'Ext.Window',
    requires : [
        'MyApp.registration.UsersGridPanel',
        'MyApp.registration.UserFormPanel'
    ],

    height : 200,
    width  : 550,
    border : false,

    layout : {
        type  : 'hbox',
        align : 'stretch'
    },

    initComponent : function() {
        this.items = this.buildItems();
        this.buttons = this.buildButtons();
        this.callParent();
    },
    buildItems : function() {
        return [
            {
                xtype     : 'MyApp.registration.UsersGridPanel',
                width     : 280,
                itemId    : 'grid',
                listeners : {
                    scope     : this,
                    itemclick : this.onGridItemClick
                }
            },
            {
                xtype  : 'MyApp.registration.UserFormPanel',
                itemId : 'userform',
                flex   : 1
            }
        ];
    },
    buildButtons : function() {
        return [
            {
                text   : 'Save',
                scope   : this,
                handler : this.onSaveBtn
            }
        ];
    },
    onGridItemClick : function(view, record) {
        this.down('#userform').loadRecord(record);
    },
    onSaveBtn : function() {
        var basicForm    = this.down('#userform').getForm(),
            loadedRecord = basicForm.getRecord();

        basicForm.updateRecord(loadedRecord);
        loadedRecord.commit();
    }

});