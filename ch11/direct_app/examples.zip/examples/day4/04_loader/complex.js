Ext.Loader.setConfig({
   enabled : true,
   paths   : {
        'MyApp' : 'js/MyApp'
   }
});


Ext.require('MyApp.registration.RegistrationWindow');

Ext.onReady(function() {
    Ext.create('MyApp.registration.RegistrationWindow').show();
});
