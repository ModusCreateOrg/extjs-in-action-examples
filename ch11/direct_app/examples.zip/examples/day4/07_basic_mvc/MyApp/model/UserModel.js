Ext.define('MyApp.model.UserModel', {
    extend   : 'Ext.data.Model',
    fields   : [
        'firstName',
        'lastName',
        'state',
        'zip'
    ]
});
