Ext.Loader.setConfig({
    enabled : true
});


Ext.application({
    name        : 'MyApp',
    appFolder   : 'MyApp',
//    autoCreateViewport : true,
    controllers : [
        'UserEditorWindow'
    ],
    launch      : function () {
        Ext.create('MyApp.view.UserEditorWindow').show();
    }
});
