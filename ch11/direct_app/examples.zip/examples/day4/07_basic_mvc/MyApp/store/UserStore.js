Ext.define('MyApp.store.UserStore', {
    extend    : 'Ext.data.Store',
    singleton : true,
    requires  : ['MyApp.model.UserModel'],

    model    : 'MyApp.model.UserModel',
    autoLoad : true,
    proxy    : {
        type : 'ajax',
        url  : 'complexData.json',
        reader : {
            type : 'json',
            root : 'records'
        }
    }
});