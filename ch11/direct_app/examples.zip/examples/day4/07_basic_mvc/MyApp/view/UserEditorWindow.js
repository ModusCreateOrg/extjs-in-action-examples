Ext.define('MyApp.view.UserEditorWindow', {
    extend   : 'Ext.Window',
    alias    : 'widget.mywindow',
    requires : [
        'MyApp.view.UsersGridPanel',
        'MyApp.view.UserFormPanel'
    ],

    closable : false,
    height   : 220,
    width    : 600,
    border   : false,

    layout   : {
        type  : 'hbox',
        align : 'stretch'
    },

    initComponent : function() {
        this.items   = this.buildItems();
        this.buttons = this.buildButtons();
        this.callParent();
    },
    buildItems : function() {
        return [
            {
                xtype  : 'UsersGridPanel',
                itemId : 'userGrid',
                flex   : 1
            },
            {
                xtype  : 'UserFormPanel',
                itemId : 'userForm',
                width  : 250
            }
        ];
    },
    buildButtons : function() {
        return [
            {
                text   : 'OK',
                action : 'closeBtn'
            }
        ]
    }
});