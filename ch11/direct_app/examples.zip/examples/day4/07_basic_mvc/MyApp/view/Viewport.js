Ext.define('MyApp.view.Viewport', {
    extend : 'Ext.Viewport',

    layout : {
        type : 'vbox',
        align : 'stretch'
    },
    defaults:  {
        title : 'A Panel',
        flex  : 1,
        frame : true
    },
    initComponent : function() {
        this.items = [
            {
                text : 'Panel1'
            },
            {
                text : 'Panel 2'
            }
        ];

        this.callParent();
    }
});