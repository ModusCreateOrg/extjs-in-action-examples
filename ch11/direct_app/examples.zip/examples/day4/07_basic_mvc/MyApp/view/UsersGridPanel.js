Ext.define('MyApp.view.UsersGridPanel', {
    extend   : 'Ext.grid.Panel',
    alias    : 'widget.UsersGridPanel',
    requires : ['MyApp.store.UserStore'],

    initComponent : function() {
        this.store   = MyApp.store.UserStore;
        this.columns = this.buildColumns();
        this.callParent();
    },

    buildColumns : function() {
        return [
            {
                header    : 'First Name',
                dataIndex : 'firstName',
                flex      : 1
            },
            {
                header    : 'Last Name',
                dataIndex : 'lastName',
                flex      : 1
            }
        ];
    }
});
