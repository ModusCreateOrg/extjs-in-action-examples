Ext.define('MyApp.view.UserFormPanel', {
    extend      : 'Ext.form.Panel',
    alias       : 'widget.UserFormPanel',

    bodyStyle   : 'padding: 10px; background-color: #DCE5F0; border-left: none;',
    defaultType : 'textfield',
    defaults    : {
        anchor     : '-10',
        labelWidth : 70
    },

    initComponent : function() {
        this.items = this.buildItems();
        this.dockedItems =  this.buildDockedItems();

        this.callParent();
    },
    buildItems : function() {
        return [
            {
                fieldLabel : 'First Name',
                name       : 'firstName'
            },
            {
                fieldLabel : 'Last Name',
                name       : 'lastName'
            },
            {
                fieldLabel : 'State',
                name       : 'state'
            },
            {
                fieldLabel : 'Zip',
                name       : 'zip'
            }
        ];
    },
    buildDockedItems : function() {
        return {
            xtype : 'toolbar',
            dock  : 'top',
            items : [
                {
                    text    : 'Save',
                    action  : 'save'
                },
                {
                    text    : 'New',
                    action  : 'new'
                },
                {
                    text    : 'Delete',
                    action  : 'delete'
                }
            ]
        }
    }
});