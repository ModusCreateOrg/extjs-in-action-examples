Ext.define('MyApp.controller.UserEditorWindow', {
    extend : 'Ext.app.Controller',
    views : ['UserEditorWindow'] ,
    init : function() {
        this.control({
            '#userGrid' : {
                itemclick : this.onGridItemClick
            },
            'button[action="new"]' : {
                click : this.onNewBtn
            },
            'button[action="save"]' : {
                click : this.onSaveBtn
            },
            'button[action="delete"]' : {
                click : this.onDeleteBtn
            },
            'button[action="closeBtn"]' : {
                click : this.onCloseBtn
            }
        })

    },
    onGridItemClick : function(view, record) {
        var ownerWindow = view.up('window'),
            formPanel   = ownerWindow.getComponent('userForm');

        formPanel.loadRecord(record)
    },
    onSaveBtn : function(btn) {
        var ownerWindow = btn.up('window'),
            gridPanel   = ownerWindow.getComponent('userGrid'),
            gridStore   = gridPanel.getStore(),
            formPanel   = ownerWindow.getComponent('userForm'),
            basicForm   = formPanel.getForm(),
            currentRec  = basicForm.getRecord(),
            formData    = basicForm.getValues(),
            storeIndex  = gridStore.indexOf(currentRec);

        //loop through the record and set values
        currentRec.beginEdit();
        currentRec.set(formData);
        currentRec.endEdit();
        currentRec.commit();

        // Add and select
        if (storeIndex == -1) {
            gridStore.add(currentRec);
            gridPanel.getSelectionModel().select(currentRec)
        }
    },
    onNewBtn : function(btn) {
        var ownerWindow = btn.up('window'),
            gridPanel   = ownerWindow.getComponent('userGrid'),
            formPanel   = ownerWindow.getComponent('userForm'),
            newModel    = Ext.ModelManager.create({}, 'MyApp.model.UserModel');

        gridPanel.getSelectionModel().clearSelections();
        formPanel.getForm().loadRecord(newModel)
    },
    onDeleteBtn : function(btn) {
        var ownerWindow      = btn.up('window'),
            formPanel        = ownerWindow.getComponent('userForm'),
            gridPanel        = ownerWindow.getComponent('userGrid'),
            basicForm        = formPanel.getForm(),
            currentRec       = basicForm.getRecord(),
            selectedRecIndex = gridPanel.store.indexOf(currentRec),
            selectedRow      = gridPanel.view.getNode(selectedRecIndex);

        if (selectedRow) {

            Ext.get(selectedRow).fadeOut({
                scope    : this,
                callback : function() {
                    currentRec.store.remove(currentRec);
                    this.onNewBtn(btn);

                }
            });

        }
    },
    onCloseBtn : function(btn) {
        btn.up('window').destroy();
    }
});