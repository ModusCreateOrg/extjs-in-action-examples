Ext.onReady(function() {
    var tpl = Ext.create('Ext.Template',
          '{firstName} {lastName} says hello!'
    );

    Ext.create('Ext.window.Window', {
        height : 140,
        width  : 200,
        border : false,
        layout : 'fit',
        items  : {
            xtype       : 'form',
            layout      : 'anchor',
            frame       : true,
            defaultType : 'textfield',
            defaults    : {
                labelWidth : 30,
                anchor     : '100%',
                allowBlank : false,
                msgTarget  : 'side'
            },
            items       : [
                {
                    fieldLabel : 'First',
                    name       : 'firstName'
                },
                {
                    fieldLabel : 'Last',
                    name       : 'lastName'
                }
            ]
        },
        buttons : [
            {
                text    : 'Submit',
                handler : function(btn) {
//                      debugger;
//                    var win  = btn.up('window'),
//                        form = win.down('form'),
//                        vals = form.getValues(),
//                        msg  = tpl.apply(vals);
//
//                    Ext.Msg.alert('Hello', msg);
                }
            }
        ]
    }).show();
});





























//Ext.onReady(function() {
//    var tpl = Ext.create('Ext.Template',
//        'Hi there {first} {last}! Nice to meet you!'
//    );
//
//    Ext.create('Ext.window.Window', {
//        height  : 150,
//        width   : 200,
//        layout  : 'fit',
//        border  : false,
//        items   : {
//            xtype  : 'form',
//            layout : 'anchor',
//            frame  : true,
//            items  : [
//                {
//                    xtype      : 'textfield',
//                    fieldLabel : 'First',
//                    anchor     : '100%',
//                    labelWidth : 45,
//                    name       : 'first'
//                },
//                {
//                    xtype      : 'textfield',
//                    fieldLabel : 'Last',
//                    anchor     : '100%',
//                    labelWidth : 45,
//                    name       : 'last'
//                }
//            ],
//            buttons : [
//                {
//                    text    : 'Submit',
//                    handler : function(btn) {
//                        var form = btn.up('form'),
//                            vals = form.getValues(),
//                            msg  = tpl.apply(vals);
//
//                        Ext.MessageBox.alert('Hello!', msg);
//                    }
//                }
//            ]
//        }
//    }).show();
//});