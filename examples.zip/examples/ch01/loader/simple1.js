//Ext.require('Ext.Panel');

Ext.onReady(function() {
    Ext.create('Ext.window.Window', {
        width    : 100,
        collapsible : true,
        html     : 'Hello programmer!!!!!'
    }).show();
});