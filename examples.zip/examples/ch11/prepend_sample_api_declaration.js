if ( Ext.syncRequire ) {
    Ext.syncRequire( 'Ext.direct.Manager' );
}

Ext.namespace( 'RPC' );